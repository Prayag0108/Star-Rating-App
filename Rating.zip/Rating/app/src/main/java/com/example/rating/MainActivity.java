package com.example.rating;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RatingBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
        RatingBar ratingBar;
        TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ratingBar = findViewById(R.id.ratingBar2);
        textView = findViewById(R.id.textView2);

    }

    public  void submit (View view){
        float ratingvalue = ratingBar.getRating();

        if (ratingvalue < 2){
            textView.setText("Rating:" + ratingvalue + "\n we will try better next time");
        }
        else if (ratingvalue <=3 && ratingvalue >=2){
            textView.setText("Rating:" + ratingvalue + "\n We are constantly improving");

        }

    }
}